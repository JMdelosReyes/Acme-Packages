
package pojos;


public class AuditorPojo extends ActorPojo {

}
