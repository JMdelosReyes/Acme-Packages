
package pojos;

public class CategoryPojo {

	private String	englishName;
	private String	spanishName;
	private String	englishDescription;
	private String	spanishDescription;


	public String getEnglishName() {
		return this.englishName;
	}

	public void setEnglishName(String englishName) {
		this.englishName = englishName;
	}

	public String getSpanishName() {
		return this.spanishName;
	}

	public void setSpanishName(String spanishName) {
		this.spanishName = spanishName;
	}

	public String getEnglishDescription() {
		return this.englishDescription;
	}

	public void setEnglishDescription(String englishDescription) {
		this.englishDescription = englishDescription;
	}

	public String getSpanishDescription() {
		return this.spanishDescription;
	}

	public void setSpanishDescription(String spanishDescription) {
		this.spanishDescription = spanishDescription;
	}

}
